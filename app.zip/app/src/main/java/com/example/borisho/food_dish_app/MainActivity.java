package com.example.borisho.food_dish_app;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public ListAdapter adapter;
    public static ListView listView;
    public static List<MenuItem> menuItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        menuItems.add(new MenuItem("USER1", "USER 1 Review Here", 4, R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground, "Wasatch Grnd and Pulp", "Avocado Toast With Egg"));
        menuItems.add(new MenuItem("USER2", "USER 2 Review Here", 1, R.drawable.ic_launcher_background, R.drawable.ic_launcher_foreground, "Pan Wok", "General Tso Chicken"));

        adapter = new MenuAdapter(this, menuItems);
        listView = (ListView) findViewById(R.id.MenuList);
        listView.setAdapter(adapter);

        final Context context = this;
        TextView header = (TextView)findViewById(R.id.FOODishHeader);
        header.setClickable(true);
        header.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, MainActivity.class));
            }
        });
    }
}
